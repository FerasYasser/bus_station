

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import static java.sql.Types.NULL;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.Line;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author feras
 */

public class Tickets {
    int i=1;
    Scanner x;
    Scanner fileScanner;
    int w=0;
    BookingGui b=new BookingGui();
    int l=b.i;
    int o=0;
    static String a;
    static String e;
    int we;
   static int z=0;
    int ah=0;
    int y;
    StringBuilder sb=new StringBuilder();
    String tic[]=new String[100];
   static  String tic2[]=new String[100];
int poo;
    int ch;

//PassengerFirst p=new PassengerFirst();
    void AddTicket(String data){
        
   
            //System.out.println(data[i]);
             
             openFile(data);
             
        
         
    }

    
    void openFile(String q){
        
          
       
    try{
            try (BufferedWriter fw=new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\Tickets.txt",true))) 
 {


   fw.append(q+"/");
  fw.newLine();
 fw.close();}
            }catch(Exception e){
            System.out.println(e);
}}
    public void print(){
try {
    x=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\Tickets.txt"));
               while(x.hasNext())
                { 
                       
                    tic2[z]=x.nextLine();
                  //  System.out.println(tic2[z]);
                    z++;
                    //System.out.println(a);   
                }
               z--;
         x.close();
        }
       
catch(Exception e){
    System.out.println("3");
}  
 }
    public String[] SearchDeletedTrip(String text){
    
    String a = "feras";
        String b = "amr";
        String c = "ahmed";
      passengergui pg=new passengergui();
String username=pg.user;
text=pg.user+" booked "+text;
        System.out.println(text);
        if (username == null ? a == null : username.equals(a)) {
                  int i = 0;
            String[] trip = new String[200];
            
            try {
                fileScanner = new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\feras.txt"));
            } catch (FileNotFoundException ex) {
                System.out.println("3");
            }
            while (fileScanner.hasNext()) {
                String codes=fileScanner.nextLine();
                if(!codes.equals(text)){
                    trip[i]=codes;
                    //System.out.println(trip[i]);
                    i++;
                }else{
                    System.out.println("a7a");
                    //fileScanner.nextLine();
                }
                
            }
            return trip;
        } else if (username == null ? b == null : username.equals(b)) {
      int i = 0;
            String[] trip = new String[200];
            
            try {
                fileScanner = new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\amr.txt"));
            } catch (FileNotFoundException ex) {
                System.out.println("3");
            }
            while (fileScanner.hasNext()) {
                String codes=fileScanner.nextLine();
                if(!codes.equals(text)){
                    trip[i]=codes;
                    System.out.println(trip[i]);
                    i++;
                }else{
                    System.out.println("a7a");
                    //fileScanner.nextLine();
                }
                
            }
            return trip;
            
        } else if (username == null ? c == null : username.equals(c)) {
                  int i = 0;
            String[] trip = new String[200];
            
            try {
                fileScanner = new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\ahmed.txt"));
            } catch (FileNotFoundException ex) {
                System.out.println("3");
            }
            while (fileScanner.hasNext()) {
                String codes=fileScanner.nextLine();
                if(!codes.equals(text)){
                    trip[i]=codes;
                    System.out.println(trip[i]);
                    i++;
                }else{
                    System.out.println("a7a");
                    //fileScanner.nextLine();
                }
                
            }
            return trip;}
 return null;
}
 public void deleteTrip(String[]string){
passengergui pg=new passengergui();
String username=pg.user;
String a="amr";
String b="feras";
String c="ahmed";
        int i=0;
        if (username == null ? a == null : username.equals(a)) {
            try {
                BufferedWriter nadimFile = new BufferedWriter(new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\amr.txt"));
                while(string[i]!=null){
                nadimFile.write(string[i]);
                nadimFile.newLine();
                System.out.println(string);
                i++;
                }
                nadimFile.close();
                } catch (IOException ex) {
               System.out.println("3");
            }
        } else if (username == null ? b == null : username.equals(b)) {
            try {
                BufferedWriter andrewFile = new BufferedWriter(new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\feras.txt"));
                while(string[i]!=null){
                andrewFile.write(string[i]);
                andrewFile.newLine();
                System.out.println(string);
                i++;
                }
                andrewFile.close();
            
            } catch (IOException ex) {
               System.out.println("3");

            }
        } else if (username == null ? c == null : username.equals(c)) {
            try {
                BufferedWriter ferasFile = new BufferedWriter(new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\ahmed.txt"));
                while(string[i]!=null){
                ferasFile.write(string[i]);
                ferasFile.newLine();
                System.out.println(string);
                i++;
                }
                ferasFile.close();
            } catch (IOException ex) {
                System.out.println("3");
            }
        } 
        }
 public String[] Mangersearch(String text){
      int i = 0;
            String[] trip = new String[200];
            
            try {
                fileScanner = new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\Tickets.txt"));
            } catch (FileNotFoundException ex) {
                System.out.println("3");
            }
            while (fileScanner.hasNext()) {
                String codes=fileScanner.nextLine();
                if(!codes.equals(text)){
                    trip[i]=codes;
                    System.out.println(trip[i]);
                    i++;
                }else{
                    System.out.println("a7a");
                    //fileScanner.nextLine();
                }
                
            }
            return trip;
 }
 public void mangerdelete(String[]string){
     try {
                BufferedWriter nadimFile = new BufferedWriter(new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\Tickets.txt"));
                int i=0;
                while(string[i]!=null){
                nadimFile.write(string[i]);
                nadimFile.newLine();
                System.out.println(string);
                i++;
                }
                nadimFile.close();
                } catch (IOException ex) {
               System.out.println("3");
            } 
 }
  public String[] searchalltrips(String text){
    
    String a = "feras";
        String b = "amr";
        String c = "ahmed";
      passengergui pg=new passengergui();
String username=pg.user;
text=pg.user+" booked "+text;
        System.out.println(text);
        if (username == null ? a == null : username.equals(a)) {
                  int i = 0;
            String[] trip = new String[200];
            
            try {
                fileScanner = new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\bookedtickets.txt"));
            } catch (FileNotFoundException ex) {
                System.out.println("3");
            }
            while (fileScanner.hasNext()) {
                String codes=fileScanner.nextLine();
                if(!codes.equals(text)){
                    trip[i]=codes;
                    //System.out.println(trip[i]);
                    i++;
                }else{
                    System.out.println("a7a");
                    //fileScanner.nextLine();
                }
                
            }
            return trip;
 }           
        return null;
  } public void deleteall(String[]string){
     try {
                BufferedWriter nadimFile = new BufferedWriter(new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\bookedtickets.txt"));
                int i=0;
                while(string[i]!=null){
                nadimFile.write(string[i]);
                nadimFile.newLine();
                System.out.println(string);
                i++;
                }
                nadimFile.close();
                } catch (IOException ex) {
               System.out.println("3");
            } 
 
  }}

   
 