
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author feras
 */
public class bookingTickets {
    private Scanner q;
     static  String bookedtic[]=new String[100];
      static  String bookedtic2[]=new String[100];
       static  String ahmedtic[]=new String[100];
        static  String alltic[]=new String[100];
        static int f;
        int am;
        static int ah;
       static int all;
    passengergui p=new passengergui();
    public void booking(String tic3){
//        System.out.println(p.user);
  //      System.out.println(tic3);
        if("feras".equals(p.user)){
            {
               
                try {
                    try (BufferedWriter feras = new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\feras.txt",true))) {
                        feras.append("feras booked "+tic3);
                        feras.newLine();
                        feras.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(bookingTickets.class.getName()).log(Level.SEVERE, null, ex);
                }
        }}
            if("amr".equals(p.user)){
            {
            try (BufferedWriter amr=new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\amr.txt",true))) 
 { amr.append("amr bookred "+tic3);
 amr.newLine();
 amr.close();
             
    }          catch (IOException ex) {
                   Logger.getLogger(bookingTickets.class.getName()).log(Level.SEVERE, null, ex);
               }
        }}
    if( "ahmed".equals(p.user)){
            {
            try (BufferedWriter ahmed=new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\ahmed.txt",true))) 
 { 
          ahmed.append("ahmed booked"+tic3);
          ahmed.newLine();
          ahmed.close();
    
    }          catch (IOException ex) {
                   Logger.getLogger(bookingTickets.class.getName()).log(Level.SEVERE, null, ex);
               }
        }}
    ////
            if("feras".equals(p.user)){
            {
               
                try {
                    try (BufferedWriter ferast = new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\bookedtickets.txt",true))) {
                        ferast.append("feras booked "+tic3);
                        ferast.newLine();
                        ferast.close();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(bookingTickets.class.getName()).log(Level.SEVERE, null, ex);
                }
        }}
            if("amr".equals(p.user)){
            {
            try (BufferedWriter amrt=new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\bookedtickets.txt",true))) 
 { amrt.append("amr bookred "+tic3);
 amrt.newLine();
 amrt.close();
             
    }          catch (IOException ex) {
                   Logger.getLogger(bookingTickets.class.getName()).log(Level.SEVERE, null, ex);
               }
        }}
    if( "ahmed".equals(p.user)){
            {
            try (BufferedWriter ahmedt=new BufferedWriter( new FileWriter("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\bookedtickets.txt",true))) 
 { 
          ahmedt.append("ahmed booked"+tic3);
          ahmedt.newLine();
          ahmedt.close();
    
    }          catch (IOException ex) {
                   Logger.getLogger(bookingTickets.class.getName()).log(Level.SEVERE, null, ex);
               }
        }}
    }    public void printUser(){
        if( "feras".equals(p.user)){
        try {
    q=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\feras.txt"));
               while(q.hasNext())
                { 
                       
                    bookedtic[f]=q.nextLine();
                  //  System.out.println(tic2[z]);
                    f++;
                    //System.out.println(a);   
                }
               f--;
         q.close();
        }
       
catch(Exception e){
    System.out.println("2");
}  }
    
    if( "ahmed".equals(p.user)){
           try {
    q=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\ahmed.txt"));
               while(q.hasNext())
                { 
                             
                    bookedtic[f]=q.nextLine();
                  //  System.out.println(tic2[z]);
                    f++;
                    //System.out.println(a);   
                }
               f--;
         
        }
       
catch(Exception e){
    System.out.println("cant find file");
}  }
    
    if( "amr".equals(p.user)){
       try {
    q=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\amr.txt"));
               while(q.hasNext())
                { 
                       
                              
                    bookedtic[f]=q.nextLine();
                  //  System.out.println(tic2[z]);
                    f++;
                    //System.out.println(a);   
                }
               f--;
         
        }
       
catch(Exception e){
    System.out.println("cant find file");
}}}
    public void mangerReading(){
               try {
    q=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\bookedtickets.txt"));
               while(q.hasNext())
                { 
                       
                              
                    alltic[all]=q.nextLine();
                  //  System.out.println(tic2[z]);
                    all++;
                    //System.out.println(a);   
                }
               all--;
         
        q.close();}
       
catch(Exception e){
    System.out.println("cant find file");
}
    }
    
}    
    

