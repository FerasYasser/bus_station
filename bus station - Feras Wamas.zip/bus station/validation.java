import java.io.*;
//import java.io.BufferedReader;
//import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
//import java.io.FileNotFoundException;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author feras
 */
public class validation {
     String a;
private Scanner x;
public Boolean File(String user,String pass){
try {
    x=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\trial.txt"));
}  
catch(Exception e){
    System.out.println("cant find file");
}

while(x.hasNext()){
     a=x.next();
    String b=x.next();
     if((user == null ? a == null : user.equals(a))&&(pass == null ? b == null : pass.equals(b)))
    {   System.out.println("welcome");
      
    PassengerFirst p=new PassengerFirst();
     p.Name(a);
     
   return true;}
    System.out.printf("%s  %s\n", a,b);
}

    x.close();
return false;}

public Boolean FileDriver(String user,String pass){
try {
    x=new Scanner(new File("C:\\Users\\feras\\Documents\\NetBeansProjects\\Busstation\\src\\driver.txt"));
}  
catch(Exception e){
    System.out.println("cant find file");
}

while(x.hasNext()){
     a=x.next();
    String b=x.next();
   
    if((user == null ? a == null : user.equals(a))&&(pass == null ? b == null : pass.equals(b)))
    {   System.out.println("welcome");
     
   return true;}
    System.out.printf("%s  %s\n", a,b);
}

    x.close();
return false;}
public boolean MangerName(String user,String pass){
    if("nour".equals(user)&&"1234".equals(pass))
    {
        System.out.println("welcome");
        return true;
        
    }
return false;}
}
